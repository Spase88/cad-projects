import ezdxf
import math

doc = ezdxf.new()
msp = doc.modelspace()

width = 1830
height = 1830

# Draw outer rectangle only
msp.add_lwpolyline([
    (0, 0),
    (width, 0),
    (width, height),
    (0, height),
    (0, 0)
], close=True)

# Arc parameters
cx, cy = width / 2, height / 2
start_offset = 22.3
end_offset = 21.0
segments = 100
points = []

for i in range(segments + 1):
    t = i / segments
    offset = start_offset + (end_offset - start_offset) * t
    radius = (width / 2) - offset
    angle = math.radians(180 - 180 * t)  # from 180° to 0°
    x = cx + radius * math.cos(angle)
    y = cy + radius * math.sin(angle)
    points.append((x, y))

# Draw tapered arc polyline
msp.add_lwpolyline(points)

doc.saveas("arc.dxf")
